<?php

$nik          = $_POST['nik'];
$nama_lengkap = $_POST['nama_lengkap'];
$password = $_POST['password'];

$format = "$nik|$nama_lengkap|$password";
$file = file('config.txt',FILE_IGNORE_NEW_LINES);
if(in_array($format, $file)){ //jika data ditemukan
    session_start();
    $_SESSION['nik'] = $nik;
    $_SESSION['nama_lengkap'] = $nama_lengkap;
    $_SESSION['password'] = $password;
    header("location:user.php");
    
}else{ //jika data tidak ditemukan ?>
    <script type="text/javascript">window
        alert('!!! Maaf Kombinasi NIK, Nama Lengkap,dan Password Salah.');
        alert('!!! Atau Data Tidak Terdaftar!!!');
        window.location.assign('index.php');
    </script>
<?php }