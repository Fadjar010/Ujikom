    <?php
session_start();
 if(empty($_SESSION['nik'])){ ?>
}else{ //jika data tidak ditemukan ?>
    <script type="text/javascript">window
        alert('!!! Apa Anda Yakin Ingin Keluar!!!');
        window.location.assign('user.php');
    </script>
<?php } ?>